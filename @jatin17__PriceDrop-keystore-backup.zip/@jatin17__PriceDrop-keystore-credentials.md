# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: 42dcc43153b644d0b38fc8313f2a354f
- Android key alias: QGphdGluMTcvUHJpY2VEcm9w
- Android key password: 4fb451e39cd24cc8b8d93d432f257217
      